package com.entity;

import java.io.InputStream;

public class User {
	
	private int id ;
	private String name ;
	private String cno;
	private String email ;
	private String dob;
	private int age;
	private String phno;
	private String branch;
	private int year;
	private String division;
	

	private int batch;
	private String mother_name ;
	private String mother_occupation;
	private String father_name ;
	private String father_occupation;
	private int siblings;
	private int family_income;
	private String blood_group;
	private String hobby;
	private String Address;
	private String achievements ;
	private String id_img ;
    private int men_id;
	

	private String password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
	
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
	
	public int getBatch() {
		return batch;
	}
	public void setBatch(int batch) {
		this.batch = batch;
	}
	
	public String getMother_name() {
		return mother_name;
	}
	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}
	public String getMother_occupation() {
		return mother_occupation;
	}
	public void setMother_occupation(String mother_occupation) {
		this.mother_occupation = mother_occupation;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getFather_occupation() {
		return father_occupation;
	}
	public void setFather_occupation(String father_occupation) {
		this.father_occupation = father_occupation;
	}
	public int getSiblings() {
		return siblings;
	}
	public void setSiblings(int siblings) {
		this.siblings = siblings;
	}
	public int getFamily_income() {
		return family_income;
	}
	public void setFamily_income(int family_income) {
		this.family_income = family_income;
	}
	public String getBlood_group() {
		return blood_group;
	}
	public void setBlood_group(String blood_group) {
		this.blood_group = blood_group;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getAchievements() {
		return achievements;
	}
	public void setAchievements(String achievements) {
		this.achievements = achievements;
	}
	public String getId_img() {
	return id_img;
	}
	public void setId_img(String id_img) {
	this.id_img = id_img;
	}
	public int getMen_id() {
		return men_id;
	}
	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", cno=" + cno + ", email=" + email + ", dob=" + dob + ", age="
				+ age + ", phno=" + phno + ", branch=" + branch + ", year=" + year + ", division=" + division
				+ ", batch=" + batch + ", mother_name=" + mother_name + ", mother_occupation=" + mother_occupation
				+ ", father_name=" + father_name + ", father_occupation=" + father_occupation + ", siblings=" + siblings
				+ ", family_income=" + family_income + ", blood_group=" + blood_group + ", hobby=" + hobby
				+ ", Address=" + Address + ", achievements=" + achievements + ", id_img=" + id_img + ", men_id="
				+ men_id + ", password=" + password + "]";
	}
	
	
	
	
	
}