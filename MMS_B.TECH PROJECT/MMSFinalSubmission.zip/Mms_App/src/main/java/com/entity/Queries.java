package com.entity;

public class Queries {
	
	private int id ;
	
	private String query ;
	private String cno;
  
    private String date ;
    private String time;
    private int men_id;
	@Override
	public String toString() {
		return "Queries [id=" + id + ", query=" + query + ", cno=" + cno + ", date=" + date
				+ ", time=" + time + ",men_id="+men_id+"]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getMen_id() {
		return men_id;
	}
	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}
	
	
	
}