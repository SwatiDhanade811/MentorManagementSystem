package com.entity;

public class Leave {


	private int id ;
	
	
	private String cno;
	
    private String date ;
    private String time ;
    private int men_id;
    private String reason ;
    
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getMen_id() {
		return men_id;
	}
	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "Leave [id=" + id + ", cno=" + cno + ", date=" + date + ", time=" + time + ", men_id=" + men_id + ", reason="
				+ reason + "]";
	}
    
	
    
	
}
