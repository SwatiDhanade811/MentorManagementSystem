package com.entity;

public class Announcements {
	private int id ;
	private String announcements ;
	private int men_id;
	 private String date ;
	 private String time ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnnouncements() {
		return announcements;
	}
	public void setAnnouncements(String announcements) {
		this.announcements = announcements;
	}
	public int getMen_id() {
		return men_id;
	}
	public void setMen_Id(int men_id) {
		this.men_id = men_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Announcements [id=" + id + ", announcements=" + announcements + ", men_id=" + men_id + ",date="+date+",time="+time+"]";
	}
	
}