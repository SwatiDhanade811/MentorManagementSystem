package com.user.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserDAOImpl;
import com.DB.DBConnect;
import com.entity.User;
import javax.servlet.http.Part;


@MultipartConfig
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			
			String name = req.getParameter("fullname");
			String cno = req.getParameter("cno");
			String email = req.getParameter("email");
		
			String dob = req.getParameter("date");
			int age =Integer.parseInt( req.getParameter("age"));
			String phno = req.getParameter("phno");
			String branch = req.getParameter("branch");
			int year=Integer.parseInt( req.getParameter("year"));
			String division = req.getParameter("div");
			int batch=Integer.parseInt( req.getParameter("batch"));
			String mother_name = req.getParameter("mname");
			String mother_occupation = req.getParameter("mocup");
			String father_name = req.getParameter("fname");
			String father_occupation = req.getParameter("focup");
			int siblings=Integer.parseInt( req.getParameter("sib"));
			int family_income=Integer.parseInt( req.getParameter("finc"));
			String blood_group = req.getParameter("bg");
			String hobby = req.getParameter("hob");
			String address = req.getParameter("add");
			
			Part p = req.getPart("achiv");
			String achievements= p.getSubmittedFileName();
			//String  = req.getParameter("achiv");
			
			
			Part part = req.getPart("img");
			String id_img = part.getSubmittedFileName();
			int men_id=Integer.parseInt( req.getParameter("men_id"));
			//String id_img= req.getParameter("img");
			//Part part=req.getPart("img");
			
			String password = req.getParameter("pass");
			String check = req.getParameter("check");
			
			//System.out.println(name+" "+email+" "+phno+" "+password+" "+check);
			
			
			User us = new User();
			us.setName(name);
			us.setCno(cno);
			us.setEmail(email);
			us.setDob(dob);
			us.setAge(age);
			
			us.setPhno(phno);
			us.setBranch(branch);
			us.setYear(year);
			us.setDivision(division);
			us.setBatch(batch);
			us.setMother_name(mother_name);
			us.setMother_occupation(mother_occupation);
            us.setFather_name(father_name);
            us.setFather_occupation(father_occupation);
            us.setSiblings(siblings);
            us.setFamily_income(family_income);
            us.setBlood_group(blood_group);
            us.setHobby(hobby);
            us.setAddress(address);
            us.setAchievements(achievements);
            us.setId_img(id_img);
            
            us.setMen_id(men_id);
           
			us.setPassword(password);
			
			HttpSession session = req.getSession();
			
			if(check!=null)
			{
				UserDAOImpl dao = new UserDAOImpl(DBConnect.getConn());
				String pa = getServletContext().getRealPath("")+"Achivements";
				String path = getServletContext().getRealPath("")+"pictures";
				
				boolean f2= dao.checkUser(email);
				if(f2) {
					
					 boolean f= dao.userRegister(us);
					 
					 if(f)
					 {
						 //System.out.println("user registration succeessful ");
						 System.out.println(path);
							
						 System.out.println(pa);
						 File fa = new File (pa);
							part.write(pa+File.separator+achievements);
							
							File file = new File (path);
							part.write(path+File.separator+id_img);// yaha meri image jab hum dalenge to sidha folder me jayegi pictures me 
							
						 
						 session.setAttribute("succMsg","user registration succeessful ");
						 resp.sendRedirect("register.jsp");
					 }
					 else
					 {
						// System.out.println("Something wrong ");
						 session.setAttribute("failedMsg","Something wrong on server");
						 resp.sendRedirect("register.jsp");
					 }
					
				}
				else
				{
					 session.setAttribute("failedMsg","user already exists ");
					 resp.sendRedirect("register.jsp");
				}
			}
			else {
				
				session.setAttribute("failedMsg","please Agree terms & conditions");
				resp.sendRedirect("register.jsp");
			}
			
			 
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		
		
		
	}
}
