package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.MentorDAOImpl;
import com.DB.DBConnect;
import com.entity.Mentor;

@WebServlet("/Mentorreg")
public class MentorRegServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
try {
			
			String name = req.getParameter("name");
			
			String email = req.getParameter("email");
		
			
			String phno = req.getParameter("phno");
			String dept= req.getParameter("dept");
			int year=Integer.parseInt( req.getParameter("year"));
			int men_id=Integer.parseInt( req.getParameter("men_id"));
			String password = req.getParameter("password");
			String check = req.getParameter("check");
			
			//System.out.println(name+" "+email+" "+phno+" "+password+" "+check);
			
			
			Mentor us = new Mentor();
			us.setName(name);
			
			us.setEmail(email);
			
			
			us.setPhno(phno);
			us.setDept(dept);
			us.setYear(year);
			us.setMen_id(men_id);
			us.setPassword(password);
			
			HttpSession session = req.getSession();
			
			if(check!=null)
			{
				MentorDAOImpl dao = new MentorDAOImpl(DBConnect.getConn());
				boolean f2= dao.checkMentorm(email);
				if(f2) {
					
					 boolean f= dao.MentorRegister(us);
					 
					 if(f)
					 {
						//System.out.println("user registration succeessful ");
						 
						 session.setAttribute("succMsg","user registration succeessful ");
						 resp.sendRedirect("mentorlogin.jsp");
					 }
					 else
					 {
						//System.out.println("Something wrong ");
						 session.setAttribute("failedMsg","Something wrong on server");
						 resp.sendRedirect("Mentorreg.jsp");
					 }
					
				}
				else
				{
					 session.setAttribute("failedMsg","user already exists ");
					 resp.sendRedirect("mentorlogin.jsp");
				}
			}
			else {
				
				session.setAttribute("failedMsg","please Agree terms & conditions");
				resp.sendRedirect("mentorlogin.jsp");
			}
			
			 
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		
		
		
	}

}
