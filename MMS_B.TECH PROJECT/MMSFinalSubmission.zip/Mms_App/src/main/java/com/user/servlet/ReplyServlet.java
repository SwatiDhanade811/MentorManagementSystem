package com.user.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.ReplyDAOImpl;
import com.DAO.UserDAOImpl;
import com.DB.DBConnect;
import com.entity.Reply;
@WebServlet("/reply")
public class ReplyServlet extends HttpServlet  {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			
			String reply= req.getParameter("reply");
			String cno=req.getParameter("cno");
			String time=req.getParameter("time");
			String date=req.getParameter("date");
			
			
			
			Reply us = new Reply();
			us.setReply(reply);
			us.setCno(cno);
			us.setTime(time);
			us.setDate(date);
			
			HttpSession session = req.getSession();
	
			
			ReplyDAOImpl dao = new ReplyDAOImpl(DBConnect.getConn());
			boolean f2= dao.checkReply(cno);
		//if(f2) {			
				 boolean f= dao.ReplyRegister(us);
				 
					 if(f)
					 {
						 //System.out.println("user registration succeessful ");
						 
						 session.setAttribute("succMsg","replied succeessfully ");
						 resp.sendRedirect("Reply.jsp");
					 }
					 else
					 {
						// System.out.println("Something wrong ");
						 session.setAttribute("failedMsg","Something wrong on server");
						 resp.sendRedirect("Reply.jsp");
					 }
					
						/*}
			else
				{
					 session.setAttribute("failedMsg"," already replied  ");
					 resp.sendRedirect("Reply.jsp");
				}*/
			
			
			
			
			 
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		
		
}
}
