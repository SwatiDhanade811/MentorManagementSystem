package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserDAOImpl;
import com.DB.DBConnect;
import com.entity.User;

@WebServlet("/update")
public class update_profile extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 try {
			 
			
			 String branch= req.getParameter("branch");
				int year = Integer.parseInt(req.getParameter("year"));
				String division =req.getParameter("div");
				int batch = Integer.parseInt(req.getParameter("batch"));
			
				
				User p = new User();
				
				p.setBranch(branch);
				p.setYear(year);
				p.setDivision(division);
				p.setBatch(batch);
			
		UserDAOImpl dao = new UserDAOImpl(DBConnect.getConn());
		boolean f= dao.updateProfile(p);
		HttpSession session = req.getSession();
     
				if(f){
					
					session.setAttribute("succMsg","Profile updated successfully !");
					resp.sendRedirect("update.jsp");
					 
					
					
					
				}else {
						
					
					 session.setAttribute("failedMsg","Something wrong on server");
					 resp.sendRedirect("update.jsp");
				 
				}
				
				
				
			 
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	}
 
	
	
}
