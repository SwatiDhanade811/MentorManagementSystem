package com.user.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.QueriesDAOImpl;
import com.DB.DBConnect;
import com.entity.Queries;
@WebServlet("/queries")
public class QueriesServlet extends HttpServlet  {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			
			String q_id= req.getParameter("query");
			String cno= req.getParameter("cno");
			
			String date = req.getParameter("date");
			String time= req.getParameter("time");
			int men_id=Integer.parseInt( req.getParameter("men_id"));
			
			
			Queries us= new Queries();
			us.setQuery(q_id);
			us.setCno(cno);
			
			us.setDate(date);
			us.setTime(time);
			us.setMen_id(men_id);
			
			
			HttpSession session = req.getSession();
			

			QueriesDAOImpl dao = new QueriesDAOImpl(DBConnect.getConn());
				boolean f2= dao.checkQueries(men_id);
				
					 boolean f= dao.QueriesRegister(us);
					 
					 if(f)
					 {
						 //System.out.println("user registration succeessful ");
						 
						 session.setAttribute("succMsg","Queries submitted successfully ");
						 resp.sendRedirect("queries.jsp");
					 }
					 else
					 {
						// System.out.println("Something wrong ");
						 session.setAttribute("failedMsg","Something wrong on server");
						 resp.sendRedirect("queries.jsp");
					 }
					

			
			 
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		
		
}
}
