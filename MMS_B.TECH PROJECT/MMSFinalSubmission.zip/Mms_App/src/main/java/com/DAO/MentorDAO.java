package com.DAO;

import java.util.List;

import com.entity.Mentor;

public interface MentorDAO {
	public  boolean MentorRegister( Mentor us );
	 
	 
	 public Mentor loginm(String email, String password);
	 
	 public  boolean checkPasswordm(int id ,String ps);
	 
	 public  boolean updateProfilem(Mentor us );
	 
	 public  boolean checkMentorm(String em );
	 public List<Mentor> getAllMentors();
}
