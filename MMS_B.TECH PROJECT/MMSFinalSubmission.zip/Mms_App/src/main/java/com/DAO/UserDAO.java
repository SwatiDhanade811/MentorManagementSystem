package com.DAO;

import java.util.List;


import com.entity.Reply;
import com.entity.User;



public interface UserDAO {
	public  boolean userRegister( User us );
	 
	 
	 public User login(String email, String password);
	 
	 public  boolean checkPassword(int id ,String ps);
	 
	
	 
	 public  boolean checkUser(String em );
	 
	 public List<User> getAllStudents();
	 public List<User> getAllStudentsbybatch(int men_id);
	 public List<User> getBatch();
	 
	 public User getUserById(String cno);
	  
	
	 
	 public List<User> getUserByYear2( );
	 public List<User> getUserByYear3( );
	 public List<User> getUserByYear4( );
	 
	 public boolean updateProfile(User p);
	       
}
