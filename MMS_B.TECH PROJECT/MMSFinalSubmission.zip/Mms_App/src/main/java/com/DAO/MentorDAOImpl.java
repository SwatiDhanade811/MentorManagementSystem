package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.entity.Mentor;
import com.entity.User;


public class MentorDAOImpl implements MentorDAO {

	private Connection conn;
	
	public MentorDAOImpl( Connection conn) {
		super();
		this.conn = conn;

		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean MentorRegister(Mentor us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into mentor(name,email,phno,dept,year,men_id,password)values(?,?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getName());
			
				ps.setString(2,us.getEmail());
				
				ps.setString(3,us.getPhno()); 
				ps.setString(4,us.getDept()); 
				ps.setInt(5,us.getYear()); 
				ps.setInt(6,us.getMen_id()); 
				ps.setString(7,us.getPassword()); 
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 } catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	@Override
	public Mentor loginm(String email, String password) {
		
			Mentor ms = null ;
			
			try { 
				
				String sql = "select *from mentor where email=? and password=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, email);
				ps.setString(2, password);
				
				ResultSet rs = ps.executeQuery();
				
				while(rs.next())
				{
					ms= new Mentor();
					
					ms.setName(rs.getString(1));
					ms.setEmail(rs.getString(2));
					ms.setPhno(rs.getString(3));
					ms.setDept(rs.getString(4));
					ms.setYear(rs.getInt(5));
					ms.setMen_id(rs.getInt(6));
					ms.setPassword(rs.getString(7));
					
					System.out.println("Mentor logged in...................");
				}
				
			}catch(Exception e )
			{
				
				e.printStackTrace();
			}
			return ms;
			
			
	}

	@Override
	public boolean checkPasswordm(int id, String ps) {
boolean f = false ;
		
		
		try {
			

			String sql = "select * from mentor where id=? and password=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,id);
			pst.setString(2,ps);
			
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				
				f=true ;
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return f;
	}

	@Override
	public boolean updateProfilem(Mentor us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "update mentor set name=?,email=?,phno=? where  id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getName());
				ps.setString(2,us.getEmail());
				ps.setString(3,us.getPhno());
				ps.setInt(4,us.getId()); 
				 
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
		
		
	}

	@Override
	public boolean checkMentorm(String em) {
boolean f= true ;
		
		try {
			 String sql = "select * from mentor where email=? ";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,em);
				
				 ResultSet rs = ps.executeQuery();
				
						 while(rs.next())
							{
								f=false;
							}
				 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	
	}
	
	@Override
	public List<Mentor> getAllMentors() {
		List<Mentor> list = new ArrayList<Mentor>();

		Mentor p = null;

		try {
			String sql = "select  name,email,phno,dept  from mentor order by name asc ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Mentor();
				p.setName(rs.getString(1));
				p.setEmail(rs.getString(2));
				p.setPhno(rs.getString(3));
				p.setDept(rs.getString(4));
				
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}
	
}
