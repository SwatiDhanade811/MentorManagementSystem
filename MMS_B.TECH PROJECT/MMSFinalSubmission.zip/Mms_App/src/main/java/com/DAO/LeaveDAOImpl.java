package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Leave;
import com.entity.Queries;
import com.entity.User;

public class LeaveDAOImpl implements LeaveDAO {
	
	
	private Connection conn;

	
	
	public LeaveDAOImpl(Connection conn) {
		super();
		this.conn = conn;

	}

	@Override
	public boolean LeaveRegister(Leave us) {
		
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into leave_app (cno,date,time,men_id,reason)values(?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1,us.getCno());
			
				ps.setString(2,us.getDate()); 
				ps.setString(3,us.getTime()); 
				ps.setInt(4,us.getMen_id()); 
				ps.setString(5,us.getReason());
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
		
		
	}

	@Override
	public boolean checkLeave(int men_id) {
		 boolean f= true ;
			
			try {
				 String sql = "select * from leave_app where men_id=? ";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setInt(1,men_id);
					
					 ResultSet rs = ps.executeQuery();
					
							 while(rs.next())
								{
									f=false;
								}
					 
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return f;
	}

	@Override
	public boolean updateLeave(Leave us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "update leave_app set ,cno=?,date=?, time=? ,men_id=? , reason=? where  id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setString(1,us.getCno());
			
				ps.setInt(2,us.getId()); 
				ps.setString(3,us.getDate()); 
				ps.setString(4,us.getTime()); 
				ps.setInt(5,us.getMen_id());
				ps.setString(6,us.getReason());
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
	}

	@Override
	public List<Leave> getAllLeaves() {
		List<Leave> list = new ArrayList<Leave>();

		Leave p = null;

		try {
			String sql = "select cno,date,time,reason from leave_app order by date desc,time desc ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Leave();
				p.setCno(rs.getString(1));
				p.setDate(rs.getString(2));
				p.setTime(rs.getString(3));
				p.setReason(rs.getString(4));
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Leave> getAllLeavesbybatch(int men_id) {
		// TODO Auto-generated method stub
		List<Leave> list = new ArrayList<Leave>();

		Leave p = null;

		try {
			String sql = "select cno,date,time,reason from leave_app where men_id= ? ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			ps.setInt(1, men_id);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Leave();
				p.setCno(rs.getString(1));
				p.setDate(rs.getString(2));
				p.setTime(rs.getString(3));
				p.setReason(rs.getString(4));
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
		
	}

	

	
	
	
	
	
}
