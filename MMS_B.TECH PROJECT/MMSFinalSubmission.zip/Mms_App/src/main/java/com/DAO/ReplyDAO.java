package com.DAO;

import java.util.List;


import com.entity.Reply;
import com.entity.User;

public interface ReplyDAO {
	public  boolean ReplyRegister( Reply us );
	 
	
	public  boolean checkReply(String cno );
	
	public List<Reply> getReplyByCno(String cno );
 
}
