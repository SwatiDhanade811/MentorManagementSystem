package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Reply;
import com.entity.Reply_leave;
import com.entity.User;

public class Reply_leaveDAOImpl implements Reply_leaveDAO{
	private Connection conn;

	public Reply_leaveDAOImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	@Override
	public boolean ReplyRegister(Reply_leave us) {
		
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into reply_leave(reply,cno,time,date)values(?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getReply());
				
				ps.setString(2,us.getCno()); 
				ps.setString(3,us.getTime()); 
				ps.setString(4,us.getDate()); 
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
	}
public boolean checkReply(String cno) {
         boolean f= true ;
		
		try {
			 String sql = "select * from reply_leave where cno=? ";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,cno);
				
				 ResultSet rs = ps.executeQuery();
				
						 while(rs.next())
							{
								f=false;
							}
				 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}






@Override
public List<Reply_leave> getReply_leaveByCno(String cno) {
	List<Reply_leave> list = new ArrayList<Reply_leave>();
	
	Reply_leave c= null ;
	
	
	try {
		
		
		String sql ="select * from reply_leave where cno=?";
		PreparedStatement ps= conn.prepareStatement(sql);
		ps.setString(1, cno);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			c= new Reply_leave();
			
			c.setReply(rs.getString(1));
			c.setCno(rs.getString(2));
			c.setTime(rs.getString(3));
			c.setDate(rs.getString(4));
			list.add(c);
			
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
	
	return list;
}














	












}
