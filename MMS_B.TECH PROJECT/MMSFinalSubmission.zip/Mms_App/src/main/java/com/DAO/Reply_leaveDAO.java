package com.DAO;

import java.util.List;


import com.entity.Reply_leave;
import com.entity.User;

public interface Reply_leaveDAO {
	public  boolean ReplyRegister( Reply_leave us );
	 
	
	public  boolean checkReply(String cno );
	
	public List<Reply_leave> getReply_leaveByCno(String cno );
 
}
