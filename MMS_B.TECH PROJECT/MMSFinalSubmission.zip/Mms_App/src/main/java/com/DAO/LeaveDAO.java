package com.DAO;

import java.util.List;

import com.entity.Leave;

import com.entity.User;

public interface LeaveDAO {
	
		public  boolean LeaveRegister( Leave us );
		 
		
		public  boolean checkLeave(int year );
		public  boolean updateLeave(Leave us );
		
		
		 public List<Leave> getAllLeaves();
		 public List<Leave> getAllLeavesbybatch(int men_id);
	
}
