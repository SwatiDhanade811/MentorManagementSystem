package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.Base64;

import com.entity.Reply;
import com.entity.User;

public class UserDAOImpl implements UserDAO{
	private Connection conn;

	public UserDAOImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	@Override
	public boolean userRegister(User us) {
		
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into user(name,cno,email,dob,age,phno,branch,year,division,batch,mother_name,mother_occupation,father_name,father_occupation,siblings,family_income,blood_group,hobby,address,achievements,id_img,men_id,password)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getName());
				ps.setString(2,us.getCno());
				ps.setString(3,us.getEmail());
				ps.setString(4,us.getDob());
				ps.setInt(5,us.getAge()); 
				ps.setString(6,us.getPhno()); 
				ps.setString(7,us.getBranch()); 
				ps.setInt(8,us.getYear()); 
				ps.setString(9,us.getDivision()); 
				ps.setInt(10,us.getBatch()); 
				ps.setString(11,us.getMother_name()); 
				ps.setString(12,us.getMother_occupation()); 
				ps.setString(13,us.getFather_name()); 
				ps.setString(14,us.getFather_occupation()); 
				ps.setInt(15,us.getSiblings()); 
				ps.setInt(16,us.getFamily_income()); 
				ps.setString(17,us.getBlood_group()); 
				ps.setString(18,us.getHobby()); 
				ps.setString(19,us.getAddress()); 
				ps.setString(20,us.getAchievements()); 
				ps.setString(21,us.getId_img());
			    ps.setInt(22,us.getMen_id());
				ps.setString(23,us.getPassword()); 
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
		
		
		
		
	}

	@Override
	public User login(String email, String password) {
		User us = null ;
		
		try { 
			
			String sql = "select *from user where email=? and password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				us= new User();
				us.setId(rs.getInt(1));
				us.setName(rs.getString(2));
				us.setCno(rs.getString(3));
				us.setEmail(rs.getString(4));
				us.setDob(rs.getString(5));
				us.setAge(rs.getInt(6));
				us.setPhno(rs.getString(7));
				us.setBranch(rs.getString(8));
				us.setYear(rs.getInt(9));
				us.setDivision(rs.getString(10));
				us.setBatch(rs.getInt(11));
				us.setMother_name(rs.getString(12));
				us.setMother_occupation(rs.getString(13));
				us.setFather_name(rs.getString(14));
				us.setFather_occupation(rs.getString(15));
				us.setSiblings(rs.getInt(16));
				us.setFamily_income(rs.getInt(17));
				us.setBlood_group(rs.getString(18));
				us.setHobby(rs.getString(19));
				us.setAddress(rs.getString(20));
				us.setAchievements(rs.getString(21));
			us.setId_img(rs.getString(22));
				
				us.setMen_id(rs.getInt(23));
				us.setPassword(rs.getString(24));
				
				System.out.println("Student logged in...................");
			}
			
		}catch(Exception e )
		{
			
			e.printStackTrace();
		}
		return us;
		
		
		
	}

	@Override
	public boolean checkPassword(int id,String ps) {
		boolean f = false ;
		
		
		try {
			

			String sql = "select * from user where id=? and password=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,id);
			pst.setString(2,ps);
			
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				
				f=true ;
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return f;
	}

	

	@Override
	public boolean checkUser(String em) {
		boolean f= true ;
		
		try {
			 String sql = "select * from user where email=? ";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,em);
				
				 ResultSet rs = ps.executeQuery();
				
						 while(rs.next())
							{
								f=false;
							}
				 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}

	@Override
	public List<User> getAllStudents() {
		List<User> list = new ArrayList<User>();

		User p = null;

		try {
			String sql = "select cno, name  from user order by cno asc ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new User();
				p.setCno(rs.getString(1));
				p.setName(rs.getString(2));
				
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public User getUserById(String cno) {
User us = null ;
		
		try { 
			
			String sql = "select * from user where cno=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cno);
			//ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				us= new User();
				us.setId(rs.getInt(1));
				us.setName(rs.getString(2));
				us.setCno(rs.getString(3));
				us.setEmail(rs.getString(4));
				us.setDob(rs.getString(5));
				us.setAge(rs.getInt(6));
				us.setPhno(rs.getString(7));
				us.setBranch(rs.getString(8));
				us.setYear(rs.getInt(9));
				us.setDivision(rs.getString(10));
				us.setBatch(rs.getInt(11));
				us.setMother_name(rs.getString(12));
				us.setMother_occupation(rs.getString(13));
				us.setFather_name(rs.getString(14));
				us.setFather_occupation(rs.getString(15));
				us.setSiblings(rs.getInt(16));
				us.setFamily_income(rs.getInt(17));
				us.setBlood_group(rs.getString(18));
				us.setHobby(rs.getString(19));
				us.setAddress(rs.getString(20));
				us.setAchievements(rs.getString(21));
	         	us.setId_img(rs.getString(22));
				us.setMen_id(rs.getInt(23));
				
				us.setPassword(rs.getString(24));
				
				
			}
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		return us;
		
	}

	@Override
	public List<User> getBatch() {
		List<User> list = new ArrayList<User>();

		User p = null;

		try {
			String sql = "select cno, name ,email from user order by cno asc ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new User();
				p.setCno(rs.getString(1));
				p.setName(rs.getString(2));
				p.setEmail(rs.getString(3));
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<User> getUserByYear2() {
		
		List<User> list = new ArrayList<User>();
		
		User c= null ;
		
		
		try {
			
			
			String sql ="select  name, cno , year  from user where year=2 order by division,batch";
			PreparedStatement ps= conn.prepareStatement(sql);
			//ps.setInt();
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				c= new User();
				
				c.setName(rs.getString(1));
				c.setCno(rs.getString(2));
				
				c.setYear(rs.getInt(3));
				list.add(c);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		return list;
	}


	
	
	
	
	@Override
	public List<User> getUserByYear3() {
		
		List<User> list = new ArrayList<User>();
		
		User c= null ;
		
		
		try {
			
			
			String sql ="select  name, cno , year  from user where year=3";
			PreparedStatement ps= conn.prepareStatement(sql);
			//ps.setInt();
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				c= new User();
				
				c.setName(rs.getString(1));
				c.setCno(rs.getString(2));
				
				c.setYear(rs.getInt(3));
				list.add(c);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		return list;
	}
	
	
	
	
	
		
		
	@Override
	public List<User> getUserByYear4() {
		
		List<User> list = new ArrayList<User>();
		
		User c= null ;
		
		
		try {
			
			
			String sql ="select  name, cno , year  from user where year=4";
			PreparedStatement ps= conn.prepareStatement(sql);
			//ps.setInt();
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				c= new User();
				
				c.setName(rs.getString(1));
				c.setCno(rs.getString(2));
				
				c.setYear(rs.getInt(3));
				list.add(c);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		return list;
	}

	@Override
	public boolean updateProfile(User p) {
		boolean f = false;

		try {

			String sql = "update user  set  branch=?,year=?,division=?,batch=? where cno=?";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, p.getBranch());
			ps.setInt(2, p.getYear());
			ps.setString(3, p.getDivision());
			ps.setInt(4, p.getBatch());
			ps.setString(5, p.getCno());

			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return f;

	}

	@Override
	public List<User> getAllStudentsbybatch(int men_id) {
		// TODO Auto-generated method stub
		List<User> list = new ArrayList<User>();

		User p = null;

		try {
			String sql = "select cno, name,email  from user where men_id=? ";
			//PreparedStatement ps = conn.prepareStatement(sql);
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, men_id);
			//ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
		
			
			
	//		ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new User();
				p.setCno(rs.getString(1));
				p.setName(rs.getString(2));
				p.setEmail(rs.getString(3));
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	}


	

	
