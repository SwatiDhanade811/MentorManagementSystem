package com.DAO;

import java.util.List;

import com.entity.Announcements;
import com.entity.Queries;
import com.entity.User;

public interface QueriesDAO {
	
		public  boolean QueriesRegister( Queries us );
		 
		
		public  boolean checkQueries(int year );
		public  boolean updateQueries(Queries us );
		public List<Queries> getAllQueries();
		 public Queries getQueryById(String cno);
		 public List<Queries> getAllQueriesbybatch(int men_id);
		
		 
	
}
