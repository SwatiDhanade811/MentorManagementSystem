package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Announcements;
import com.entity.User;

public class AnnouncementsDAOImpl implements AnnouncementsDAO{
	private Connection conn;

	public AnnouncementsDAOImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	@Override
	public boolean AnnouncementsRegister(Announcements us) {
		
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into announcements(announcements,men_id,date,time)values(?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getAnnouncements());
				
				ps.setInt(2,us.getMen_id()); 
				ps.setString(3,us.getDate());
				ps.setString(4,us.getTime());
			
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
	}
public boolean checkAnnouncements(int men_id) {
         boolean f= true ;
		
		try {
			 String sql = "select * from announcements where men_id=? ";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1,men_id);
				
				 ResultSet rs = ps.executeQuery();
				
						 while(rs.next())
							{
								f=false;
							}
				 
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}

	@Override
	public boolean updateAnnouncements(Announcements us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "update announcements set announcements=?,men_id=?,date=?,time=? where  id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getAnnouncements());
				ps.setInt(2,us.getId());
				ps.setInt(3,us.getMen_id());
				ps.setString(4,us.getDate());
				ps.setString(5,us.getTime());
		
				
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
		
	}

	

	@Override
	public List<Announcements> getAllAnnouncements() {
		List<Announcements> list = new ArrayList<Announcements>();

		Announcements p = null;

		try {
			String sql = "select * from announcements order by order by date desc,time desc ";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Announcements();
				p.setAnnouncements(rs.getString(1));
				p.setMen_Id(rs.getInt(2));
				p.setDate(rs.getString(3));
				p.setTime(rs.getString(4));
				
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<Announcements> getAllAnnouncementsbybatch(int men_id) {
		// TODO Auto-generated method stub
		
		List<Announcements> list = new ArrayList<Announcements>();

		Announcements p = null;

		try {
			String sql = "select announcements,date,time from announcements where men_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			
			ps.setInt(1, men_id);
			//ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
		
			
			
	//		ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Announcements();
				p.setAnnouncements(rs.getString(1));
				
				p.setDate(rs.getString(2));
				p.setTime(rs.getString(3));
				

				list.add(p);
			
			
			
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}

}