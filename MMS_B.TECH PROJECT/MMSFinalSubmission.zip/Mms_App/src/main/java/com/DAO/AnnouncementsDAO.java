package com.DAO;

import java.util.List;

import com.entity.Announcements;
import com.entity.User;

public interface AnnouncementsDAO {
	
		public  boolean AnnouncementsRegister( Announcements us );
		 
		
		public  boolean checkAnnouncements(int year );
		public  boolean updateAnnouncements(Announcements us );
		public List<Announcements> getAllAnnouncements();
		public List<Announcements> getAllAnnouncementsbybatch(int men_id);
		
		
		 
	
}
