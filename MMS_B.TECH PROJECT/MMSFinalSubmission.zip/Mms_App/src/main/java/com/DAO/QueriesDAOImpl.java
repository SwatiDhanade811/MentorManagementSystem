package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Announcements;
import com.entity.Queries;
import com.entity.User;

public class QueriesDAOImpl implements QueriesDAO{
	
	private Connection conn;

	public QueriesDAOImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	@Override
	public boolean QueriesRegister(Queries us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "insert into queries(query,cno,date,time,men_id)values(?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getQuery());
				ps.setString(2,us.getCno());
		
				ps.setString(3,us.getDate()); 
				ps.setString(4,us.getTime());
				ps.setInt(5,us.getMen_id());
				
			
				  
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
	}

	@Override
	public boolean checkQueries(int men_id) {
		 boolean f= true ;
			
			try {
				 String sql = "select * from queries where men_id=? ";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setInt(1,men_id);
					
					 ResultSet rs = ps.executeQuery();
					
							 while(rs.next())
								{
									f=false;
								}
					 
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return f;
	}

	@Override
	public boolean updateQueries(Queries us) {
		boolean f = false ;
		 try {
			 
			
			 String sql = "update queries set query=?,cno=? ,date=?, time=? ,men_id=? where  id=?";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1,us.getQuery());
				ps.setString(2,us.getCno());
				
				ps.setInt(3,us.getId()); 
				ps.setString(4,us.getDate()); 
				ps.setString(5,us.getTime()); 
				ps.setInt(6,us.getMen_id());
				
				 
				int i=ps.executeUpdate();
				
				if(i==1)
				{
					f=true ;
				}
	 
			 
		 }catch (Exception e)
		 {
			 e.printStackTrace();
		 }
		return f ;
	}

	@Override
	public List<Queries> getAllQueries() {
		List<Queries> list = new ArrayList<Queries>();

		Queries p = null;

		try {
			String sql = "select * from queries order by date desc,time desc";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Queries();
				p.setQuery(rs.getString(1));
				p.setCno(rs.getString(2));

				p.setDate(rs.getString(3));
		        p.setTime(rs.getString(4));
		        p.setMen_id(rs.getInt(5));
				

				list.add(p);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Queries getQueryById(String cno) {
              Queries us = null ;
		
		try { 
			
			String sql = "select * from queries where cno=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cno);
			//ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				us= new Queries();
				us.setId(rs.getInt(1));
				us.setQuery(rs.getString(2));
			
				us.setCno(rs.getString(3));
				
		
				us.setDate(rs.getString(4));
				us.setTime(rs.getString(5));
				us.setMen_id(rs.getInt(6));
				
				
			}
			
		}catch(Exception e )
		{
			e.printStackTrace();
		}
		return us;
		
	}
	
	@Override
	public List<Queries> getAllQueriesbybatch(int men_id) {
		// TODO Auto-generated method stub

		List<Queries> list = new ArrayList<Queries>();

		Queries p = null;

		try {
			String sql = "select * from queries where men_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			
		
			
			
			
			ps.setInt(1, men_id);
			//ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
		
			
			
	//		ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				p = new Queries();
				p.setQuery(rs.getString(1));
				p.setCno(rs.getString(2));
				p.setDate(rs.getString(3));
				p.setTime(rs.getString(4));
				
				

				list.add(p);
			
			
			
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;
	}


	
}
